leman_russ = {
    name: "Леман Русс передан из объекта, нах!",
    post: "Примарх"
}
logan_grimnar = {
    name: "Логан Гримнар передан из объекта, нах!",
    post: "Волчий лорд"
}


module.exports = {
    leman_russ: leman_russ,
    logan_grimnar: logan_grimnar
}